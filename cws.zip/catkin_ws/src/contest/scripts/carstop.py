#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from jetracer.nvidia_racecar import NvidiaRacecar

car = NvidiaRacecar()
car.throttle = -0.0
car.steering = 0.0
